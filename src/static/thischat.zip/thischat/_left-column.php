<div class="left-column">
  <div class="chat-list">
    <div class="chat-list-ttl">チャットルーム</div>
    <div class="chat-list-items"><a href="">AllChat</a></div>
    <div class="chat-list-items chat-active"><a href="">○○</a></div>
    <div class="chat-list-items"><a href="">▲▲</a></div>
    <div class="chat-list-items"><a href="">□□</a></div>
  </div>
</div>