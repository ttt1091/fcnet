<div class="right-column">
  <div class="right-items">
    <div class="right-info">
      <dl>
        <dt>Infomation</dt>
        <dd>
          <div class="right-info-date">2021/07/27</div>  
          <div class="right-info-body">ここにお知らせを記載</div>
          <div class="right-info-user">post:○○</div>
        </dd>
        <dd>
          <div class="right-info-date">2021/07/26</div>  
          <div class="right-info-body">ここにお知らせを記載</div>
          <div class="right-info-user">post:○○</div>
        </dd>
        <dd>
          <div class="right-info-date">2021/07/25</div>  
          <div class="right-info-body">ここにお知らせを記載</div>
          <div class="right-info-user">post:○○</div>
        </dd>
        <dd>
          <div class="right-info-date">2021/07/24</div>  
          <div class="right-info-body">ここにお知らせを記載</div>
          <div class="right-info-user">post:○○</div>
        </dd>
        <dd>
          <div class="right-info-date">2021/07/23</div>  
          <div class="right-info-body">ここにお知らせを記載</div>
          <div class="right-info-user">post:○○</div>
        </dd>
      </dl>
    </div>
  </div>
</div>