<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ThisChat</title>
  <link rel="stylesheet" href="css/styles.css?d=<?= rand() ?>">
</head>
<body>
<div class="wrap flex-column">
    <div class="header-nav">
      <div class="header-nav-title"><h1><a href="">ThisChat</a></h1></div>
      <div>aaa</div>
      <div class="sp-only">
        <button id="hnmt" class="header-nav-menu-trigger" onclick="menuToggle();">
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
      <div id="hni" class="header-nav-item">
        <div class="header-nav-ttl sp-only">MENU</div>
        <div class="header-nav-items"><a href="http://desktop-khet33c:8000/thischat/">ThisChat</a></div>
        <div class="header-nav-items"><a href="">test</a></div>
        <div class="header-nav-items"><a href="">test</a></div>
      </div>
      <div id="hnc" class="header-nav-close" onclick="menuCloseToggle();"></div>
    </div>

    <div class="content flex">
      <?php include('_left-column.php'); ?>
      <main class="main-column flex-column">
        <div class="chat-ttl">○○とのチャットルーム</div>
        <div class="chat-body">
<?php for ($i = 1; $i <= 6; $i++) { ?>
          <div class="chat-items flex">
            <div class="chat-items-thumb">
              <img src="static/images/dummy-001.jpg" alt="">
            </div>
            <div class="chat-items-right">
              <div class="chat-items-top">
                <div class="chat-send-name">菅義偉</div>
                <div class="chat-send-time">2021/07/25 12:32</div>
              </div>
              <div class="chat-items-body">
                こんにちは<br>
                これはテストです。
              </div>
            </div>
          </div>
<?php } ?>
        </div>
        <div class="post-form">
          <form action="">
            <div class="post-form-wrap">
              <div class="post-form-bar">
                <div></div>
                <div><button class="send-button">送信</button></div>
              </div>
              <div class="post-form-body">
                <textarea name="" id="" placeholder="メッセージ入力"></textarea>
              </div>
            </div>
          </form>
        </div>
      </main>
      
      <?php include('_right-column.php'); ?>
      
    </div>
  </div>

<script>
function menuToggle() {
  var target = document.getElementById('hnmt');
  var targetHeaderNavClose = document.getElementById('hnc');
  var targetHeaderNavItem = document.getElementById('hni');
  target.classList.toggle('active');
  targetHeaderNavClose.classList.toggle('header-nav-close-view');
  targetHeaderNavItem.classList.toggle('header-nav-view');
}
function menuCloseToggle() {
  var target = document.getElementById('hnmt');
  var targetHeaderNavClose = document.getElementById('hnc');
  var targetHeaderNavItem = document.getElementById('hni');
  target.classList.toggle('active');
  targetHeaderNavClose.classList.toggle('header-nav-close-view');
  targetHeaderNavItem.classList.toggle('header-nav-view');
}
</script>
</body>
</html>